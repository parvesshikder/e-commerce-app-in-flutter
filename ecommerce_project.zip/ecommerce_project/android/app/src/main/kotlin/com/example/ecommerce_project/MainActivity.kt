package com.example.ecommerce_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
